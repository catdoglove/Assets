﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AllNumber : MonoBehaviour {

	public int chapter1 = 1, chapter2 = 2;
	public int typeWho = 1, typeWhen = 2, typeWhere = 3, typeAct = 4, typeWhat = 5, typeEnd = 6;

}
